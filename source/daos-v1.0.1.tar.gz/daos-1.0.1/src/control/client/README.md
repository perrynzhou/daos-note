# Client API

The client API is the interface between client and server gRPC applications and provides capabilities to manage storage and network hardware local to the storage nodes in addition to DAOS pools and services.
