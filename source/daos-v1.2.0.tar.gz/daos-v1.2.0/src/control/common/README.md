# Common

Common utilities for file access, collection manipulation (including some functional helper methods), unit tests and mocks among others.
This package will be imported from multiple other packages under its parent directory and to avoid cyclical import dependencies files in this package should not import from peer packages unless absolutely necessary.
